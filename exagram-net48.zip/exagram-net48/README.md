# Exagram — .NET Framework 4.8

SaaS para análise de hemogramas com IA. Migrado de Python (FastAPI + React) para **ASP.NET MVC 5 + Web API 2**.

## Requisitos

- Visual Studio 2019 ou 2022 (ou Build Tools for Visual Studio)
- .NET Framework 4.8 SDK
- IIS ou IIS Express para rodar localmente
- MySQL 5.7+ (banco externo já configurado em `Web.config`)

## Instalação

### 1. Abrir no Visual Studio

```
Abrir Exagram.sln no Visual Studio
```

### 2. Restaurar pacotes NuGet

```
No menu: Tools → NuGet Package Manager → Package Manager Console
> Update-Package -reinstall
```

Ou via CLI:
```
nuget restore Exagram.sln
```

### 3. Configurar Web.config

As credenciais já estão preenchidas em `Exagram/Web.config` com os valores do ambiente atual.
Para produção, substitua os valores em `<appSettings>`:

- `DbHost`, `DbUser`, `DbPassword`, `DbName` — Banco MySQL
- `AnthropicApiKey`, `OpenAiApiKey`, `GeminiApiKey` — APIs de IA
- `MpAccessToken`, `MpPublicKey` — Mercado Pago
- `AdminEmail`, `AdminPassword` — Credenciais do admin
- `JwtSecret` — Segredo JWT (use uma string aleatória longa)

### 4. Executar

Pressione **F5** no Visual Studio (IIS Express) ou publique no IIS.

## Estrutura do Projeto

```
Exagram/
├── App_Start/
│   ├── WebApiConfig.cs     — Configuração do Web API 2 (CORS, rotas)
│   ├── RouteConfig.cs      — Rotas MVC (páginas)
│   └── FilterConfig.cs
├── Controllers/
│   ├── HomeController.cs   — Renderiza as views (páginas)
│   └── Api/
│       ├── AuthController.cs       — POST /api/auth/login, /register
│       ├── ExamsController.cs      — Upload e chat de exames
│       ├── PaymentsController.cs   — Mercado Pago checkout
│       ├── AdminController.cs      — CRUD admin
│       ├── SpecialistsController.cs
│       ├── ConsentController.cs
│       ├── UserController.cs       — LGPD (exportar/excluir)
│       └── WebhooksController.cs   — Webhook Mercado Pago
├── Models/           — DTOs de request/response
├── Services/
│   ├── DatabaseService.cs  — MySQL (helper de queries)
│   ├── AuthService.cs      — JWT + bcrypt
│   ├── AiService.cs        — Chamadas Gemini, Claude, OpenAI
│   └── MercadoPagoService.cs
├── Filters/
│   └── JwtAuthAttribute.cs — Autenticação por token nos endpoints
├── Views/
│   ├── Home/Index.cshtml       — Landing page
│   ├── Auth/Login.cshtml
│   ├── Auth/Register.cshtml
│   ├── Dashboard/Index.cshtml
│   ├── Exam/Result.cshtml      — Resultado + chat
│   └── Admin/                  — Painel admin
└── Content/site.css
```

## Rotas da API

| Método | Rota | Autenticação |
|--------|------|-------------|
| POST | /api/auth/register | — |
| POST | /api/auth/login | — |
| GET | /api/auth/me | User |
| POST | /api/admin/login | — |
| POST | /api/exams/upload | User |
| GET | /api/exams | User |
| GET | /api/exams/{id} | User |
| POST | /api/exams/{id}/chat | User |
| POST | /api/payments/checkout | User |
| POST | /api/payments/validate-coupon | User |
| GET | /api/payments/status/{id} | User |
| GET | /api/packages | — |
| GET | /api/specialists | — |
| POST | /api/webhooks/mercadopago | — |
| GET | /api/user/data | User |
| DELETE | /api/user/account | User |
| GET | /api/admin/overview | Admin |
| GET/POST | /api/admin/tenants | Admin |
| PATCH/DELETE | /api/admin/tenants/{id} | Admin |
| POST/PATCH/DELETE | /api/admin/specialists | Admin |
| GET/POST/PATCH/DELETE | /api/admin/coupons | Admin |
| GET | /api/admin/audit-log | Admin |

## Credenciais de Teste

| Tipo | Email | Senha |
|------|-------|-------|
| Usuário | teste@exagram.com.br | Teste123! |
| Admin | admin@exagram.com.br | Exagram@Admin2024 |

## Tecnologias

- **ASP.NET MVC 5** — Páginas Razor
- **Web API 2** — REST API
- **MySQL** — `MySql.Data` 8.4
- **JWT** — `System.IdentityModel.Tokens.Jwt` 6.35
- **Bcrypt** — `BCrypt.Net-Next` 4.0
- **IA** — Chamadas HTTP diretas: Gemini 2.5 Flash (extração), Claude Sonnet (análise), GPT-4o (fallback)
- **Pagamentos** — Mercado Pago REST API
