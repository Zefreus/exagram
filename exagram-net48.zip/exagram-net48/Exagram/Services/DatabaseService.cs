using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using BCrypt.Net;

namespace Exagram.Services
{
    public static class DatabaseService
    {
        private static string ConnectionString =>
            $"Server={Cfg("DbHost")};Port={Cfg("DbPort")};Database={Cfg("DbName")};" +
            $"Uid={Cfg("DbUser")};Pwd={Cfg("DbPassword")};CharSet=utf8mb4;SslMode=none;";

        private static string Cfg(string key) => ConfigurationManager.AppSettings[key];

        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(ConnectionString);
        }

        public static async Task<List<Dictionary<string, object>>> QueryAsync(string sql, Dictionary<string, object> parameters = null)
        {
            var results = new List<Dictionary<string, object>>();
            using (var conn = GetConnection())
            {
                await conn.OpenAsync();
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    if (parameters != null)
                        foreach (var p in parameters)
                            cmd.Parameters.AddWithValue(p.Key, p.Value ?? DBNull.Value);

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                                row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                            results.Add(row);
                        }
                    }
                }
            }
            return results;
        }

        public static async Task<Dictionary<string, object>> QueryOneAsync(string sql, Dictionary<string, object> parameters = null)
        {
            var rows = await QueryAsync(sql, parameters);
            return rows.Count > 0 ? rows[0] : null;
        }

        public static async Task ExecuteAsync(string sql, Dictionary<string, object> parameters = null)
        {
            using (var conn = GetConnection())
            {
                await conn.OpenAsync();
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    if (parameters != null)
                        foreach (var p in parameters)
                            cmd.Parameters.AddWithValue(p.Key, p.Value ?? DBNull.Value);
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }

        public static async Task InitializeAsync()
        {
            var tables = new[]
            {
                @"CREATE TABLE IF NOT EXISTS exa_admins (
                    id VARCHAR(36) PRIMARY KEY,
                    email VARCHAR(255) UNIQUE NOT NULL,
                    password_hash VARCHAR(255) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )",
                @"CREATE TABLE IF NOT EXISTS exa_tenants (
                    id VARCHAR(36) PRIMARY KEY,
                    name VARCHAR(255) NOT NULL,
                    slug VARCHAR(255),
                    plan ENUM('free','pro') DEFAULT 'free',
                    exam_credits INT DEFAULT 1,
                    active BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )",
                @"CREATE TABLE IF NOT EXISTS exa_users (
                    id VARCHAR(36) PRIMARY KEY,
                    tenant_id VARCHAR(36) UNIQUE,
                    email VARCHAR(255) UNIQUE NOT NULL,
                    password_hash VARCHAR(255) NOT NULL,
                    name VARCHAR(255),
                    consent_granted BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (tenant_id) REFERENCES exa_tenants(id) ON DELETE CASCADE
                )",
                @"CREATE TABLE IF NOT EXISTS exa_exams (
                    id VARCHAR(36) PRIMARY KEY,
                    user_id VARCHAR(36) NOT NULL,
                    tenant_id VARCHAR(36) NOT NULL,
                    extracted_data LONGTEXT,
                    ai_analysis LONGTEXT,
                    flags LONGTEXT,
                    summary TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_tenant_id (tenant_id)
                )",
                @"CREATE TABLE IF NOT EXISTS exa_chat_messages (
                    id VARCHAR(36) PRIMARY KEY,
                    exam_id VARCHAR(36) NOT NULL,
                    user_id VARCHAR(36) NOT NULL,
                    role ENUM('user','assistant') NOT NULL,
                    content TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_exam_id (exam_id)
                )",
                @"CREATE TABLE IF NOT EXISTS exa_specialists (
                    id VARCHAR(36) PRIMARY KEY,
                    name VARCHAR(255) NOT NULL,
                    specialty VARCHAR(255) NOT NULL,
                    type ENUM('medico','clinica','hospital') NOT NULL,
                    city VARCHAR(255),
                    state VARCHAR(50),
                    phone VARCHAR(50),
                    website VARCHAR(255),
                    email VARCHAR(255),
                    description TEXT,
                    active BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )",
                @"CREATE TABLE IF NOT EXISTS exa_usage_tracking (
                    id VARCHAR(36) PRIMARY KEY,
                    tenant_id VARCHAR(36) NOT NULL,
                    month_year VARCHAR(7) NOT NULL,
                    exam_count INT DEFAULT 0,
                    UNIQUE KEY unique_tenant_month (tenant_id, month_year)
                )",
                @"CREATE TABLE IF NOT EXISTS exa_consents (
                    id VARCHAR(36) PRIMARY KEY,
                    user_id VARCHAR(36) NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    consent_version VARCHAR(20) NOT NULL,
                    ip_address VARCHAR(50),
                    user_agent TEXT,
                    action ENUM('granted','revoked') NOT NULL,
                    type ENUM('terms','privacy','sensitive_data') NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES exa_users(id) ON DELETE CASCADE
                )",
                @"CREATE TABLE IF NOT EXISTS exa_audit_log (
                    id VARCHAR(36) PRIMARY KEY,
                    event_type VARCHAR(100) NOT NULL,
                    affected_count INT DEFAULT 0,
                    tenant_id VARCHAR(36),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )",
                @"CREATE TABLE IF NOT EXISTS exa_payment_transactions (
                    id VARCHAR(36) PRIMARY KEY,
                    tenant_id VARCHAR(36) NOT NULL,
                    session_id VARCHAR(255) UNIQUE,
                    amount DECIMAL(10,2),
                    currency VARCHAR(10),
                    credits_purchased INT,
                    payment_status VARCHAR(50) DEFAULT 'pending',
                    package_id VARCHAR(50),
                    coupon_code VARCHAR(50),
                    original_amount DECIMAL(10,2),
                    discount_amount DECIMAL(10,2),
                    mp_payment_id VARCHAR(100),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_tenant_id (tenant_id)
                )",
                @"CREATE TABLE IF NOT EXISTS exa_coupons (
                    id VARCHAR(36) PRIMARY KEY,
                    code VARCHAR(50) UNIQUE NOT NULL,
                    discount_type ENUM('percent','fixed') NOT NULL,
                    discount_value DECIMAL(10,2) NOT NULL,
                    max_redemptions INT DEFAULT NULL,
                    times_redeemed INT DEFAULT 0,
                    expires_at DATETIME DEFAULT NULL,
                    active BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )"
            };

            foreach (var sql in tables)
            {
                try { await ExecuteAsync(sql); }
                catch (Exception ex) { System.Diagnostics.Debug.WriteLine($"Tabela já existe: {ex.Message}"); }
            }

            // Cria admin padrão se não existir
            var adminEmail = Cfg("AdminEmail");
            var adminPassword = Cfg("AdminPassword");
            var existing = await QueryOneAsync(
                "SELECT id FROM exa_admins WHERE email = @email",
                new Dictionary<string, object> { ["@email"] = adminEmail }
            );

            if (existing == null)
            {
                var hash = BCrypt.Net.BCrypt.HashPassword(adminPassword);
                await ExecuteAsync(
                    "INSERT INTO exa_admins (id, email, password_hash) VALUES (@id, @email, @hash)",
                    new Dictionary<string, object>
                    {
                        ["@id"] = Guid.NewGuid().ToString(),
                        ["@email"] = adminEmail,
                        ["@hash"] = hash
                    }
                );
            }
        }
    }
}
