using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace Exagram.Services
{
    public static class AuthService
    {
        private static string JwtSecret => ConfigurationManager.AppSettings["JwtSecret"];
        private static int ExpirationHours => int.Parse(ConfigurationManager.AppSettings["JwtExpirationHours"] ?? "24");

        public static string CreateToken(string userId, string userType, string tenantId = null, string email = null)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtSecret));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new Claim("user_id", userId),
                new Claim("user_type", userType),
                new Claim("tenant_id", tenantId ?? ""),
                new Claim("email", email ?? "")
            };

            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.UtcNow.AddHours(ExpirationHours),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public static ClaimsPrincipal ValidateToken(string token)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtSecret));
            var handler = new JwtSecurityTokenHandler();

            var validationParams = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = key,
                ValidateIssuer = false,
                ValidateAudience = false,
                ClockSkew = TimeSpan.Zero
            };

            return handler.ValidateToken(token, validationParams, out _);
        }

        public static Dictionary<string, string> GetClaims(string token)
        {
            var principal = ValidateToken(token);
            var result = new Dictionary<string, string>();
            foreach (var claim in principal.Claims)
                result[claim.Type] = claim.Value;
            return result;
        }

        public static string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }

        public static bool VerifyPassword(string password, string hash)
        {
            return BCrypt.Net.BCrypt.Verify(password, hash);
        }
    }
}
