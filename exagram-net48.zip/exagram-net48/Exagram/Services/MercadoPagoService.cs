using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Exagram.Services
{
    public class PreferenceResult
    {
        public string Id { get; set; }
        public string InitPoint { get; set; }
    }

    public static class MercadoPagoService
    {
        private static string AccessToken => ConfigurationManager.AppSettings["MpAccessToken"];
        private static readonly HttpClient Http = new HttpClient();

        public static async Task<PreferenceResult> CreatePreferenceAsync(
            string itemTitle, decimal unitPrice, string payerEmail,
            string externalReference, string backUrlBase, string notificationUrl)
        {
            var body = new
            {
                items = new[]
                {
                    new
                    {
                        title = itemTitle,
                        quantity = 1,
                        unit_price = Math.Round(unitPrice, 2),
                        currency_id = "BRL"
                    }
                },
                payer = new { email = payerEmail },
                payment_methods = new { installments = 3 },
                back_urls = new
                {
                    success = $"{backUrlBase}/dashboard?payment=success",
                    failure = $"{backUrlBase}/dashboard?payment=failure",
                    pending = $"{backUrlBase}/dashboard?payment=pending"
                },
                auto_return = "approved",
                external_reference = externalReference,
                notification_url = notificationUrl
            };

            var json = JsonConvert.SerializeObject(body);
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.mercadopago.com/checkout/preferences")
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            };
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", AccessToken);

            var response = await Http.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"MercadoPago error {response.StatusCode}: {content}");

            var parsed = JObject.Parse(content);
            return new PreferenceResult
            {
                Id = parsed["id"]?.ToString(),
                InitPoint = parsed["init_point"]?.ToString()
            };
        }

        public static async Task<List<JObject>> SearchPaymentsByExternalRef(string externalRef)
        {
            var url = $"https://api.mercadopago.com/v1/payments/search?external_reference={Uri.EscapeDataString(externalRef)}";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", AccessToken);

            var response = await Http.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                return new List<JObject>();

            var parsed = JObject.Parse(content);
            var results = parsed["results"] as JArray ?? new JArray();
            var list = new List<JObject>();
            foreach (JObject item in results)
                list.Add(item);
            return list;
        }

        public static async Task<JObject> GetPaymentAsync(string paymentId)
        {
            var url = $"https://api.mercadopago.com/v1/payments/{paymentId}";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", AccessToken);

            var response = await Http.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                return null;

            return JObject.Parse(content);
        }
    }
}
