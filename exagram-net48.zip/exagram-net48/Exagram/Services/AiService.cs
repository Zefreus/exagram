using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Exagram.Services
{
    public class AiResult
    {
        public string Text { get; set; }
        public string Provider { get; set; }
    }

    public static class AiService
    {
        private static string AnthropicKey => ConfigurationManager.AppSettings["AnthropicApiKey"];
        private static string OpenAiKey => ConfigurationManager.AppSettings["OpenAiApiKey"];
        private static string GeminiKey => ConfigurationManager.AppSettings["GeminiApiKey"];

        private static readonly HttpClient Http = new HttpClient { Timeout = TimeSpan.FromSeconds(120) };

        // ── Gemini: extração de arquivos (visão) ──────────────────────────────
        public static async Task<AiResult> CallGeminiExtractionAsync(string systemMessage, string userMessage, byte[] fileBytes, string mimeType)
        {
            var key = GeminiKey;
            if (string.IsNullOrEmpty(key))
                throw new Exception("GeminiApiKey não configurado");

            var base64File = Convert.ToBase64String(fileBytes);

            var body = new
            {
                system_instruction = new { parts = new[] { new { text = systemMessage } } },
                contents = new[]
                {
                    new
                    {
                        parts = new object[]
                        {
                            new { text = userMessage },
                            new { inline_data = new { mime_type = mimeType, data = base64File } }
                        }
                    }
                },
                generationConfig = new { temperature = 0.1 }
            };

            var json = JsonConvert.SerializeObject(body);
            var url = $"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={key}";

            var request = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            };

            var response = await Http.SendAsync(request);
            var responseStr = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"Gemini error {response.StatusCode}: {responseStr}");

            var parsed = JObject.Parse(responseStr);
            var text = parsed["candidates"]?[0]?["content"]?["parts"]?[0]?["text"]?.ToString();

            return new AiResult { Text = text, Provider = "gemini" };
        }

        // ── Claude: análise e chat ─────────────────────────────────────────────
        public static async Task<AiResult> CallClaudeAsync(string systemMessage, string userMessage)
        {
            var key = AnthropicKey;
            if (string.IsNullOrEmpty(key))
                throw new Exception("AnthropicApiKey não configurado");

            var body = new
            {
                model = "claude-sonnet-4-5",
                max_tokens = 4096,
                system = systemMessage,
                messages = new[] { new { role = "user", content = userMessage } }
            };

            var json = JsonConvert.SerializeObject(body);
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.anthropic.com/v1/messages")
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            };
            request.Headers.Add("x-api-key", key);
            request.Headers.Add("anthropic-version", "2023-06-01");

            var response = await Http.SendAsync(request);
            var responseStr = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"Claude error {response.StatusCode}: {responseStr}");

            var parsed = JObject.Parse(responseStr);
            var text = parsed["content"]?[0]?["text"]?.ToString();

            return new AiResult { Text = text, Provider = "claude" };
        }

        // ── OpenAI: fallback de análise e chat ───────────────────────────────
        public static async Task<AiResult> CallOpenAiAsync(string systemMessage, string userMessage)
        {
            var key = OpenAiKey;
            if (string.IsNullOrEmpty(key))
                throw new Exception("OpenAiApiKey não configurado");

            var body = new
            {
                model = "gpt-4o",
                messages = new[]
                {
                    new { role = "system", content = systemMessage },
                    new { role = "user", content = userMessage }
                }
            };

            var json = JsonConvert.SerializeObject(body);
            var request = new HttpRequestMessage(HttpMethod.Post, "https://api.openai.com/v1/chat/completions")
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            };
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", key);

            var response = await Http.SendAsync(request);
            var responseStr = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"OpenAI error {response.StatusCode}: {responseStr}");

            var parsed = JObject.Parse(responseStr);
            var text = parsed["choices"]?[0]?["message"]?["content"]?.ToString();

            return new AiResult { Text = text, Provider = "openai" };
        }

        // ── Fallback: Claude → OpenAI ────────────────────────────────────────
        public static async Task<AiResult> CallWithFallbackAsync(string systemMessage, string userMessage)
        {
            var errors = new List<string>();

            // 1. Claude
            if (!string.IsNullOrEmpty(AnthropicKey))
            {
                try { return await CallClaudeAsync(systemMessage, userMessage); }
                catch (Exception ex) { errors.Add($"Claude: {ex.Message}"); }
            }

            // 2. OpenAI
            if (!string.IsNullOrEmpty(OpenAiKey))
            {
                try { return await CallOpenAiAsync(systemMessage, userMessage); }
                catch (Exception ex) { errors.Add($"OpenAI: {ex.Message}"); }
            }

            throw new Exception($"Todos os provedores de IA falharam: {string.Join("; ", errors)}");
        }

        // ── Limpa JSON vindo da IA ────────────────────────────────────────────
        public static string CleanJsonResponse(string raw)
        {
            if (string.IsNullOrEmpty(raw)) return raw;
            var text = raw.Trim();
            if (text.StartsWith("```"))
            {
                var firstNewline = text.IndexOf('\n');
                if (firstNewline >= 0) text = text.Substring(firstNewline + 1);
                if (text.EndsWith("```")) text = text.Substring(0, text.Length - 3);
            }
            return text.Trim();
        }
    }
}
