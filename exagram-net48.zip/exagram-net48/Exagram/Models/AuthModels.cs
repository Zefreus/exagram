using System.ComponentModel.DataAnnotations;

namespace Exagram.Models
{
    public class UserRegisterRequest
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [MinLength(6)]
        public string Password { get; set; }

        [Required]
        public string Name { get; set; }
    }

    public class UserLoginRequest
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }
    }

    public class AdminLoginRequest
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }
    }

    public class UserResponse
    {
        public string Id { get; set; }
        public string Email { get; set; }
        public string TenantId { get; set; }
        public string Name { get; set; }
        public int ExamCredits { get; set; }
        public string Plan { get; set; }
        public bool ConsentGranted { get; set; }
    }

    public class AuthResponse
    {
        public string Token { get; set; }
        public UserResponse User { get; set; }
    }

    public class AdminAuthResponse
    {
        public string Token { get; set; }
        public AdminInfo Admin { get; set; }
    }

    public class AdminInfo
    {
        public string Id { get; set; }
        public string Email { get; set; }
    }

    public class ConsentGrantRequest
    {
        public string Type { get; set; }
        public string IpAddress { get; set; }
        public string UserAgent { get; set; }
    }
}
