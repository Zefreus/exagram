using System;
using System.ComponentModel.DataAnnotations;

namespace Exagram.Models
{
    public class TenantCreateRequest
    {
        [Required]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }
    }

    public class AdminOverviewResponse
    {
        public int TotalTenants { get; set; }
        public int ActiveSubscriptions { get; set; }
        public int ExamsThisMonth { get; set; }
    }
}
