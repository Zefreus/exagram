namespace Exagram.Models
{
    public class SpecialistResponse
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Specialty { get; set; }
        public string Type { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Phone { get; set; }
        public string Website { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
        public bool Active { get; set; }
    }

    public class SpecialistCreateRequest
    {
        public string Name { get; set; }
        public string Specialty { get; set; }
        public string Type { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Phone { get; set; }
        public string Website { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
    }

    public class SpecialistUpdateRequest
    {
        public string Name { get; set; }
        public string Specialty { get; set; }
        public string Type { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Phone { get; set; }
        public string Website { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
        public bool? Active { get; set; }
    }
}
