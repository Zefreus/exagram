using System.ComponentModel.DataAnnotations;

namespace Exagram.Models
{
    public class CheckoutRequest
    {
        [Required]
        public string PackageId { get; set; }

        [Required]
        public string OriginUrl { get; set; }

        public string CouponCode { get; set; }
    }

    public class CheckoutResponse
    {
        public string Url { get; set; }
        public string SessionId { get; set; }
        public decimal OriginalPrice { get; set; }
        public decimal FinalPrice { get; set; }
        public string CouponApplied { get; set; }
    }

    public class CouponValidateRequest
    {
        [Required]
        public string Code { get; set; }
    }

    public class CouponValidateResponse
    {
        public bool Valid { get; set; }
        public string Message { get; set; }
        public string DiscountType { get; set; }
        public decimal DiscountValue { get; set; }
    }

    public class PackageInfo
    {
        public string Id { get; set; }
        public int Credits { get; set; }
        public decimal Amount { get; set; }
        public string Name { get; set; }
    }

    public class CouponCreateRequest
    {
        [Required]
        public string Code { get; set; }

        [Required]
        public string DiscountType { get; set; }

        public decimal DiscountValue { get; set; }
        public int? MaxRedemptions { get; set; }
        public string ExpiresAt { get; set; }
    }
}
