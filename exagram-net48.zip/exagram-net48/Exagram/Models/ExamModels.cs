using System;
using System.Collections.Generic;

namespace Exagram.Models
{
    public class ChatMessageRequest
    {
        public string Content { get; set; }
    }

    public class ExamSummaryResponse
    {
        public string Id { get; set; }
        public string Summary { get; set; }
        public string CreatedAt { get; set; }
    }

    public class ExamDetailResponse
    {
        public string Id { get; set; }
        public object ExtractedData { get; set; }
        public object Analysis { get; set; }
        public object Flags { get; set; }
        public string Summary { get; set; }
        public string CreatedAt { get; set; }
        public List<ChatMessageResponse> Messages { get; set; }
        public List<SpecialistResponse> Specialists { get; set; }
    }

    public class ChatMessageResponse
    {
        public string Id { get; set; }
        public string Role { get; set; }
        public string Content { get; set; }
        public string CreatedAt { get; set; }
    }

    public class ExamUploadResponse
    {
        public string ExamId { get; set; }
        public object ExtractedData { get; set; }
        public object Analysis { get; set; }
        public int CreditsRemaining { get; set; }
    }

    public class ChatResponse
    {
        public ChatMessageResponse UserMessage { get; set; }
        public ChatMessageResponse AiResponse { get; set; }
    }
}
