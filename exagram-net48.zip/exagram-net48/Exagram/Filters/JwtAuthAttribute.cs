using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Controllers;
using Exagram.Services;

namespace Exagram.Filters
{
    /// <summary>
    /// Protege endpoints de usuário comum. Injeta claims no ActionArguments["currentUser"].
    /// </summary>
    public class JwtUserAuthAttribute : AuthorizeAttribute
    {
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            var auth = actionContext.Request.Headers.Authorization;
            if (auth == null || auth.Scheme != "Bearer" || string.IsNullOrEmpty(auth.Parameter))
            {
                Fail(actionContext, "Não autenticado");
                return;
            }

            try
            {
                var claims = AuthService.GetClaims(auth.Parameter);
                if (!claims.TryGetValue("user_type", out var userType) || userType != "user")
                {
                    Fail(actionContext, "Acesso negado");
                    return;
                }
                actionContext.ActionArguments["currentUser"] = claims;
            }
            catch
            {
                Fail(actionContext, "Token inválido ou expirado");
            }
        }

        private void Fail(HttpActionContext ctx, string message)
        {
            ctx.Response = ctx.Request.CreateResponse(HttpStatusCode.Unauthorized,
                new { detail = message });
        }
    }

    /// <summary>
    /// Protege endpoints de admin. Injeta claims no ActionArguments["currentAdmin"].
    /// </summary>
    public class JwtAdminAuthAttribute : AuthorizeAttribute
    {
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            var auth = actionContext.Request.Headers.Authorization;
            if (auth == null || auth.Scheme != "Bearer" || string.IsNullOrEmpty(auth.Parameter))
            {
                Fail(actionContext, "Não autenticado");
                return;
            }

            try
            {
                var claims = AuthService.GetClaims(auth.Parameter);
                if (!claims.TryGetValue("user_type", out var userType) || userType != "admin")
                {
                    Fail(actionContext, "Acesso negado — apenas administradores");
                    return;
                }
                actionContext.ActionArguments["currentAdmin"] = claims;
            }
            catch
            {
                Fail(actionContext, "Token inválido ou expirado");
            }
        }

        private void Fail(HttpActionContext ctx, string message)
        {
            ctx.Response = ctx.Request.CreateResponse(HttpStatusCode.Unauthorized,
                new { detail = message });
        }
    }
}
