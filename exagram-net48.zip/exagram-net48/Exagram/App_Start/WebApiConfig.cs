using System.Web.Http;
using System.Web.Http.Cors;

namespace Exagram
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // CORS global
            var cors = new EnableCorsAttribute("*", "*", "*");
            config.EnableCors(cors);

            // Roteamento API com prefixo /api
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            // JSON como padrão
            var json = config.Formatters.JsonFormatter;
            json.SerializerSettings.ContractResolver =
                new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver();
            config.Formatters.Remove(config.Formatters.XmlFormatter);
        }
    }
}
