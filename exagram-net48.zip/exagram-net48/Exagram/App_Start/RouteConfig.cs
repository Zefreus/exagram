using System.Web.Mvc;
using System.Web.Routing;

namespace Exagram
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            // Rotas MVC (páginas)
            routes.MapRoute(
                name: "AdminLogin",
                url: "admin/login",
                defaults: new { controller = "Home", action = "AdminLogin" }
            );
            routes.MapRoute(
                name: "Admin",
                url: "admin",
                defaults: new { controller = "Home", action = "Admin" }
            );
            routes.MapRoute(
                name: "Login",
                url: "login",
                defaults: new { controller = "Home", action = "Login" }
            );
            routes.MapRoute(
                name: "Register",
                url: "register",
                defaults: new { controller = "Home", action = "Register" }
            );
            routes.MapRoute(
                name: "Dashboard",
                url: "dashboard",
                defaults: new { controller = "Home", action = "Dashboard" }
            );
            routes.MapRoute(
                name: "ExamResult",
                url: "exam/{id}",
                defaults: new { controller = "Home", action = "ExamResult", id = UrlParameter.Optional }
            );
            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
