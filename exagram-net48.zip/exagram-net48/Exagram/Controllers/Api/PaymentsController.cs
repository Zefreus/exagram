using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using Exagram.Filters;
using Exagram.Models;
using Exagram.Services;
using Newtonsoft.Json;

namespace Exagram.Controllers.Api
{
    [RoutePrefix("api/payments")]
    public class PaymentsController : ApiController
    {
        private static readonly Dictionary<string, (int Credits, decimal Amount, string Name)> Packages
            = new Dictionary<string, (int, decimal, string)>
            {
                ["single"] = (1,  9.90m,  "1 análise"),
                ["pack3"]  = (3,  19.90m, "Pacote 3 análises"),
                ["pack10"] = (10, 49.90m, "Pacote 10 análises")
            };

        // POST api/payments/checkout
        [HttpPost, Route("checkout")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> Checkout([FromBody] CheckoutRequest data,
            Dictionary<string, string> currentUser = null)
        {
            if (data == null || !Packages.ContainsKey(data.PackageId))
                return BadRequest("Pacote inválido");

            var (credits, originalAmount, name) = Packages[data.PackageId];
            var finalPrice = originalAmount;
            string couponApplied = null;

            // Aplica cupom
            if (!string.IsNullOrEmpty(data.CouponCode))
            {
                var coupon = await DatabaseService.QueryOneAsync(
                    @"SELECT * FROM exa_coupons WHERE code = @code AND active = TRUE
                      AND (expires_at IS NULL OR expires_at > NOW())
                      AND (max_redemptions IS NULL OR times_redeemed < max_redemptions)",
                    new Dictionary<string, object> { ["@code"] = data.CouponCode.ToUpper() });

                if (coupon != null)
                {
                    var discountVal = Convert.ToDecimal(coupon["discount_value"]);
                    if (coupon["discount_type"].ToString() == "percent")
                        finalPrice = finalPrice * (1 - discountVal / 100);
                    else
                        finalPrice = finalPrice - discountVal;

                    finalPrice = Math.Max(0, finalPrice);
                    couponApplied = data.CouponCode.ToUpper();
                }
            }

            var tenantId = currentUser["tenant_id"];
            var userId = currentUser["user_id"];

            var userRow = await DatabaseService.QueryOneAsync(
                "SELECT email FROM exa_users WHERE id = @id",
                new Dictionary<string, object> { ["@id"] = userId });

            var payerEmail = userRow?["email"]?.ToString() ?? currentUser.GetValueOrDefault("email", "");

            var externalRef = JsonConvert.SerializeObject(new
            {
                tenant_id = tenantId,
                credits = credits,
                coupon_code = couponApplied,
                package_id = data.PackageId
            });

            try
            {
                var preference = await MercadoPagoService.CreatePreferenceAsync(
                    $"{name} — Exagram",
                    finalPrice,
                    payerEmail,
                    externalRef,
                    data.OriginUrl,
                    $"{data.OriginUrl}/api/webhooks/mercadopago"
                );

                await DatabaseService.ExecuteAsync(
                    @"INSERT INTO exa_payment_transactions
                      (id, tenant_id, session_id, amount, currency, credits_purchased, payment_status, package_id, coupon_code, original_amount, discount_amount, created_at)
                      VALUES (@id,@tid,@sid,@amt,'BRL',@cr,'pending',@pkg,@cpn,@orig,@disc,NOW())",
                    new Dictionary<string, object>
                    {
                        ["@id"] = Guid.NewGuid().ToString(), ["@tid"] = tenantId,
                        ["@sid"] = preference.Id, ["@amt"] = Math.Round(finalPrice, 2),
                        ["@cr"] = credits, ["@pkg"] = data.PackageId,
                        ["@cpn"] = couponApplied, ["@orig"] = originalAmount,
                        ["@disc"] = couponApplied != null ? originalAmount - finalPrice : 0
                    });

                return Ok(new CheckoutResponse
                {
                    Url = preference.InitPoint,
                    SessionId = preference.Id,
                    OriginalPrice = originalAmount,
                    FinalPrice = Math.Round(finalPrice, 2),
                    CouponApplied = couponApplied
                });
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Erro ao criar sessão de pagamento"));
            }
        }

        // POST api/payments/validate-coupon
        [HttpPost, Route("validate-coupon")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> ValidateCoupon([FromBody] CouponValidateRequest data,
            Dictionary<string, string> currentUser = null)
        {
            var coupon = await DatabaseService.QueryOneAsync(
                @"SELECT code, discount_type, discount_value FROM exa_coupons
                  WHERE code = @code AND active = TRUE
                  AND (expires_at IS NULL OR expires_at > NOW())
                  AND (max_redemptions IS NULL OR times_redeemed < max_redemptions)",
                new Dictionary<string, object> { ["@code"] = data.Code.ToUpper() });

            if (coupon == null)
                return Ok(new { valid = false, message = "Cupom inválido ou expirado" });

            return Ok(new
            {
                valid = true,
                discountType = coupon["discount_type"],
                discountValue = Convert.ToDecimal(coupon["discount_value"])
            });
        }

        // GET api/payments/status/{preferenceId}
        [HttpGet, Route("status/{preferenceId}")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> Status(string preferenceId,
            Dictionary<string, string> currentUser = null)
        {
            var tenantId = currentUser["tenant_id"];
            try
            {
                var payments = await MercadoPagoService.SearchPaymentsByExternalRef(preferenceId);
                var transaction = await DatabaseService.QueryOneAsync(
                    "SELECT payment_status, credits_purchased, coupon_code FROM exa_payment_transactions WHERE session_id = @sid AND tenant_id = @tid",
                    new Dictionary<string, object> { ["@sid"] = preferenceId, ["@tid"] = tenantId });

                foreach (var payment in payments)
                {
                    if (payment["status"]?.ToString() == "approved")
                    {
                        if (transaction != null && transaction["payment_status"]?.ToString() != "completed")
                        {
                            var credits = Convert.ToInt32(transaction["credits_purchased"]);
                            await DatabaseService.ExecuteAsync(
                                "UPDATE exa_tenants SET exam_credits = exam_credits + @cr WHERE id = @id",
                                new Dictionary<string, object> { ["@cr"] = credits, ["@id"] = tenantId });

                            await DatabaseService.ExecuteAsync(
                                "UPDATE exa_payment_transactions SET payment_status = 'completed' WHERE session_id = @sid",
                                new Dictionary<string, object> { ["@sid"] = preferenceId });

                            var couponCode = transaction["coupon_code"]?.ToString();
                            if (!string.IsNullOrEmpty(couponCode))
                                await DatabaseService.ExecuteAsync(
                                    "UPDATE exa_coupons SET times_redeemed = times_redeemed + 1 WHERE code = @code",
                                    new Dictionary<string, object> { ["@code"] = couponCode });
                        }
                        return Ok(new { status = "complete", paymentStatus = "paid", amount = payment["transaction_amount"], currency = "BRL" });
                    }
                }

                return Ok(new { status = "pending", paymentStatus = "pending", amount = 0, currency = "BRL" });
            }
            catch (Exception)
            {
                return InternalServerError(new Exception("Erro ao verificar pagamento"));
            }
        }
    }
}
