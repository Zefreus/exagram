using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;

namespace Exagram.Controllers.Api
{
    [RoutePrefix("api/packages")]
    public class PackagesController : ApiController
    {
        private static readonly Dictionary<string, object> Packages = new Dictionary<string, object>
        {
            ["single"] = new { id = "single", credits = 1, amount = 9.90m, name = "1 análise" },
            ["pack3"]  = new { id = "pack3",  credits = 3, amount = 19.90m, name = "Pacote 3 análises" },
            ["pack10"] = new { id = "pack10", credits = 10, amount = 49.90m, name = "Pacote 10 análises" }
        };

        // GET api/packages
        [HttpGet, Route("")]
        public IHttpActionResult GetPackages()
        {
            return Ok(new { packages = Packages.Values });
        }
    }
}
