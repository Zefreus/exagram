using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using Exagram.Filters;
using Exagram.Models;
using Exagram.Services;
using BCrypt.Net;

namespace Exagram.Controllers.Api
{
    [RoutePrefix("api/admin")]
    public class AdminController : ApiController
    {
        // GET api/admin/overview
        [HttpGet, Route("overview")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> Overview(Dictionary<string, string> currentAdmin = null)
        {
            var totalTenants = await DatabaseService.QueryOneAsync("SELECT COUNT(*) as count FROM exa_tenants");
            var activeSubs = await DatabaseService.QueryOneAsync("SELECT COUNT(*) as count FROM exa_tenants WHERE plan = 'pro'");
            var monthYear = DateTime.UtcNow.ToString("yyyy-MM");
            var examsThisMonth = await DatabaseService.QueryOneAsync(
                "SELECT COALESCE(SUM(exam_count),0) as count FROM exa_usage_tracking WHERE month_year = @my",
                new Dictionary<string, object> { ["@my"] = monthYear });

            return Ok(new AdminOverviewResponse
            {
                TotalTenants = Convert.ToInt32(totalTenants?["count"] ?? 0),
                ActiveSubscriptions = Convert.ToInt32(activeSubs?["count"] ?? 0),
                ExamsThisMonth = Convert.ToInt32(examsThisMonth?["count"] ?? 0)
            });
        }

        // GET api/admin/tenants
        [HttpGet, Route("tenants")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> GetTenants(Dictionary<string, string> currentAdmin = null)
        {
            var rows = await DatabaseService.QueryAsync(
                @"SELECT t.*, u.email as user_email,
                  (SELECT COUNT(*) FROM exa_exams WHERE tenant_id = t.id) as exam_count
                  FROM exa_tenants t
                  LEFT JOIN exa_users u ON t.id = u.tenant_id
                  ORDER BY t.created_at DESC LIMIT 100");

            return Ok(rows.Select(r => new
            {
                id = r["id"],
                name = r["name"],
                slug = r["slug"],
                plan = r["plan"],
                examCredits = Convert.ToInt32(r["exam_credits"]),
                active = Convert.ToBoolean(r["active"]),
                createdAt = r["created_at"] is DateTime dt ? dt.ToString("o") : r["created_at"]?.ToString(),
                userEmail = r["user_email"],
                examCount = Convert.ToInt32(r["exam_count"])
            }));
        }

        // POST api/admin/tenants
        [HttpPost, Route("tenants")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> CreateTenant([FromBody] TenantCreateRequest data,
            Dictionary<string, string> currentAdmin = null)
        {
            var existing = await DatabaseService.QueryOneAsync(
                "SELECT id FROM exa_users WHERE email = @email",
                new Dictionary<string, object> { ["@email"] = data.Email });

            if (existing != null)
                return Content(System.Net.HttpStatusCode.BadRequest, new { detail = "Email já cadastrado" });

            var tenantId = Guid.NewGuid().ToString();
            var slug = data.Email.Split('@')[0] + "_" + tenantId.Substring(0, 8);
            await DatabaseService.ExecuteAsync(
                "INSERT INTO exa_tenants (id, name, slug, plan, exam_credits, active, created_at) VALUES (@id,@name,@slug,'free',1,TRUE,NOW())",
                new Dictionary<string, object> { ["@id"] = tenantId, ["@name"] = data.Name, ["@slug"] = slug });

            var userId = Guid.NewGuid().ToString();
            var hash = AuthService.HashPassword(data.Password);
            await DatabaseService.ExecuteAsync(
                "INSERT INTO exa_users (id, tenant_id, email, password_hash, name, created_at) VALUES (@id,@tid,@email,@hash,@name,NOW())",
                new Dictionary<string, object>
                {
                    ["@id"] = userId, ["@tid"] = tenantId, ["@email"] = data.Email,
                    ["@hash"] = hash, ["@name"] = data.Name
                });

            return Ok(new { tenantId, userId, email = data.Email });
        }

        // PATCH api/admin/tenants/{id}
        [HttpPatch, Route("tenants/{id}")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> UpdateTenant(string id, [FromBody] dynamic body,
            Dictionary<string, string> currentAdmin = null)
        {
            bool active = (bool)body.active;
            await DatabaseService.ExecuteAsync(
                "UPDATE exa_tenants SET active = @active WHERE id = @id",
                new Dictionary<string, object> { ["@active"] = active, ["@id"] = id });
            return Ok(new { success = true });
        }

        // DELETE api/admin/tenants/{id}
        [HttpDelete, Route("tenants/{id}")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> DeleteTenant(string id,
            Dictionary<string, string> currentAdmin = null)
        {
            var examCount = await DatabaseService.QueryOneAsync(
                "SELECT COUNT(*) as count FROM exa_exams WHERE tenant_id = @tid",
                new Dictionary<string, object> { ["@tid"] = id });

            await DatabaseService.ExecuteAsync(
                "INSERT INTO exa_audit_log (id, event_type, affected_count, tenant_id) VALUES (@id,'tenant_deletion',@ct,@tid)",
                new Dictionary<string, object>
                {
                    ["@id"] = Guid.NewGuid().ToString(),
                    ["@ct"] = Convert.ToInt32(examCount?["count"] ?? 0),
                    ["@tid"] = id
                });

            var user = await DatabaseService.QueryOneAsync("SELECT id FROM exa_users WHERE tenant_id = @tid",
                new Dictionary<string, object> { ["@tid"] = id });

            if (user != null)
            {
                var uid = user["id"].ToString();
                await DatabaseService.ExecuteAsync("DELETE FROM exa_chat_messages WHERE user_id = @id", new Dictionary<string, object> { ["@id"] = uid });
                await DatabaseService.ExecuteAsync("DELETE FROM exa_exams WHERE user_id = @id", new Dictionary<string, object> { ["@id"] = uid });
                await DatabaseService.ExecuteAsync("DELETE FROM exa_consents WHERE user_id = @id", new Dictionary<string, object> { ["@id"] = uid });
                await DatabaseService.ExecuteAsync("DELETE FROM exa_users WHERE tenant_id = @id", new Dictionary<string, object> { ["@id"] = id });
            }

            await DatabaseService.ExecuteAsync("DELETE FROM exa_usage_tracking WHERE tenant_id = @id", new Dictionary<string, object> { ["@id"] = id });
            await DatabaseService.ExecuteAsync("DELETE FROM exa_payment_transactions WHERE tenant_id = @id", new Dictionary<string, object> { ["@id"] = id });
            await DatabaseService.ExecuteAsync("DELETE FROM exa_tenants WHERE id = @id", new Dictionary<string, object> { ["@id"] = id });

            return Ok(new { success = true });
        }

        // POST api/admin/specialists
        [HttpPost, Route("specialists")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> CreateSpecialist([FromBody] SpecialistCreateRequest data,
            Dictionary<string, string> currentAdmin = null)
        {
            var id = Guid.NewGuid().ToString();
            await DatabaseService.ExecuteAsync(
                @"INSERT INTO exa_specialists (id, name, specialty, type, city, state, phone, website, email, description)
                  VALUES (@id,@name,@sp,@type,@city,@state,@phone,@web,@email,@desc)",
                new Dictionary<string, object>
                {
                    ["@id"] = id, ["@name"] = data.Name, ["@sp"] = data.Specialty,
                    ["@type"] = data.Type, ["@city"] = data.City, ["@state"] = data.State,
                    ["@phone"] = data.Phone, ["@web"] = data.Website,
                    ["@email"] = data.Email, ["@desc"] = data.Description
                });
            return Ok(new { id });
        }

        // PATCH api/admin/specialists/{id}
        [HttpPatch, Route("specialists/{id}")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> UpdateSpecialist(string id,
            [FromBody] SpecialistUpdateRequest data, Dictionary<string, string> currentAdmin = null)
        {
            var updates = new List<string>();
            var pars = new Dictionary<string, object>();

            if (data.Name != null) { updates.Add("name = @name"); pars["@name"] = data.Name; }
            if (data.Specialty != null) { updates.Add("specialty = @sp"); pars["@sp"] = data.Specialty; }
            if (data.Type != null) { updates.Add("type = @type"); pars["@type"] = data.Type; }
            if (data.City != null) { updates.Add("city = @city"); pars["@city"] = data.City; }
            if (data.State != null) { updates.Add("state = @state"); pars["@state"] = data.State; }
            if (data.Phone != null) { updates.Add("phone = @phone"); pars["@phone"] = data.Phone; }
            if (data.Website != null) { updates.Add("website = @web"); pars["@web"] = data.Website; }
            if (data.Email != null) { updates.Add("email = @email"); pars["@email"] = data.Email; }
            if (data.Description != null) { updates.Add("description = @desc"); pars["@desc"] = data.Description; }
            if (data.Active.HasValue) { updates.Add("active = @active"); pars["@active"] = data.Active.Value; }

            if (updates.Count > 0)
            {
                pars["@id"] = id;
                await DatabaseService.ExecuteAsync(
                    $"UPDATE exa_specialists SET {string.Join(", ", updates)} WHERE id = @id", pars);
            }
            return Ok(new { success = true });
        }

        // DELETE api/admin/specialists/{id}
        [HttpDelete, Route("specialists/{id}")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> DeleteSpecialist(string id,
            Dictionary<string, string> currentAdmin = null)
        {
            await DatabaseService.ExecuteAsync("DELETE FROM exa_specialists WHERE id = @id",
                new Dictionary<string, object> { ["@id"] = id });
            return Ok(new { success = true });
        }

        // GET api/admin/coupons
        [HttpGet, Route("coupons")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> GetCoupons(Dictionary<string, string> currentAdmin = null)
        {
            var rows = await DatabaseService.QueryAsync(
                "SELECT * FROM exa_coupons ORDER BY created_at DESC LIMIT 100");

            return Ok(rows.Select(c => new
            {
                id = c["id"],
                code = c["code"],
                discountType = c["discount_type"],
                discountValue = Convert.ToDecimal(c["discount_value"]),
                maxRedemptions = c["max_redemptions"],
                timesRedeemed = Convert.ToInt32(c["times_redeemed"]),
                expiresAt = c["expires_at"] is DateTime edt ? edt.ToString("o") : c["expires_at"]?.ToString(),
                active = Convert.ToBoolean(c["active"]),
                createdAt = c["created_at"] is DateTime cdt ? cdt.ToString("o") : c["created_at"]?.ToString()
            }));
        }

        // POST api/admin/coupons
        [HttpPost, Route("coupons")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> CreateCoupon([FromBody] CouponCreateRequest data,
            Dictionary<string, string> currentAdmin = null)
        {
            var code = data.Code.ToUpper();
            var existing = await DatabaseService.QueryOneAsync(
                "SELECT id FROM exa_coupons WHERE code = @code",
                new Dictionary<string, object> { ["@code"] = code });

            if (existing != null)
                return Content(System.Net.HttpStatusCode.BadRequest, new { detail = "Código de cupom já existe" });

            DateTime? expiresAt = null;
            if (!string.IsNullOrEmpty(data.ExpiresAt))
                DateTime.TryParse(data.ExpiresAt, out var parsed);

            var id = Guid.NewGuid().ToString();
            await DatabaseService.ExecuteAsync(
                "INSERT INTO exa_coupons (id, code, discount_type, discount_value, max_redemptions, expires_at) VALUES (@id,@code,@dt,@dv,@mr,@ea)",
                new Dictionary<string, object>
                {
                    ["@id"] = id, ["@code"] = code, ["@dt"] = data.DiscountType,
                    ["@dv"] = data.DiscountValue, ["@mr"] = data.MaxRedemptions,
                    ["@ea"] = (object)expiresAt ?? DBNull.Value
                });

            return Ok(new { id, code });
        }

        // PATCH api/admin/coupons/{id}
        [HttpPatch, Route("coupons/{id}")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> UpdateCoupon(string id, [FromBody] dynamic body,
            Dictionary<string, string> currentAdmin = null)
        {
            bool active = (bool)body.active;
            await DatabaseService.ExecuteAsync(
                "UPDATE exa_coupons SET active = @active WHERE id = @id",
                new Dictionary<string, object> { ["@active"] = active, ["@id"] = id });
            return Ok(new { success = true });
        }

        // DELETE api/admin/coupons/{id}
        [HttpDelete, Route("coupons/{id}")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> DeleteCoupon(string id,
            Dictionary<string, string> currentAdmin = null)
        {
            await DatabaseService.ExecuteAsync("DELETE FROM exa_coupons WHERE id = @id",
                new Dictionary<string, object> { ["@id"] = id });
            return Ok(new { success = true });
        }

        // GET api/admin/audit-log
        [HttpGet, Route("audit-log")]
        [JwtAdminAuth]
        public async Task<IHttpActionResult> AuditLog(Dictionary<string, string> currentAdmin = null)
        {
            var rows = await DatabaseService.QueryAsync(
                "SELECT * FROM exa_audit_log ORDER BY created_at DESC LIMIT 100");

            return Ok(rows.Select(r => new
            {
                id = r["id"],
                eventType = r["event_type"],
                affectedCount = r["affected_count"],
                tenantId = r["tenant_id"],
                createdAt = r["created_at"] is DateTime dt ? dt.ToString("o") : r["created_at"]?.ToString()
            }));
        }
    }
}
