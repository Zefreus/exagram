using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using Exagram.Filters;
using Exagram.Models;
using Exagram.Services;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Exagram.Controllers.Api
{
    [RoutePrefix("api/exams")]
    public class ExamsController : ApiController
    {
        private const string ExtractionSystem = @"Você é um especialista em análise de hemogramas.
Extraia TODOS os valores do exame de sangue da imagem/PDF fornecido.
Retorne um JSON com a estrutura:
{
    ""valores"": {
        ""hemoglobina"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""hematocrito"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""eritrocitos"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""leucocitos"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""plaquetas"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""vcm"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""hcm"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""chcm"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""neutrofilos"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""linfocitos"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""eosinofilos"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""basofilos"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number},
        ""monocitos"": {""valor"": number, ""unidade"": string, ""referencia_min"": number, ""referencia_max"": number}
    },
    ""laboratorio"": string,
    ""data_exame"": string
}
Retorne APENAS o JSON, sem markdown ou explicações.";

        private const string AnalysisSystem = @"Você é um assistente de saúde empático e acolhedor. Analise os valores do hemograma e forneça:
1. Um resumo caloroso e tranquilizador em português brasileiro
2. Flags para cada valor: ""normal"", ""borderline"" ou ""attention""
3. Lista de especialistas sugeridos baseado em valores alterados

Retorne JSON:
{
    ""summary"": ""texto do resumo acolhedor"",
    ""flags"": {""hemoglobina"": ""normal"", ...},
    ""suggested_exa_specialists"": [""Hematologista"", ...]
}";

        // POST api/exams/upload
        [HttpPost, Route("upload")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> Upload(Dictionary<string, string> currentUser = null)
        {
            if (!Request.Content.IsMimeMultipartContent())
                return BadRequest("Envie o arquivo como multipart/form-data");

            var tenantId = currentUser["tenant_id"];
            var userId = currentUser["user_id"];

            // Verifica créditos
            var tenant = await DatabaseService.QueryOneAsync(
                "SELECT exam_credits FROM exa_tenants WHERE id = @id",
                new Dictionary<string, object> { ["@id"] = tenantId });

            if (tenant == null || Convert.ToInt32(tenant["exam_credits"]) < 1)
                return Content(HttpStatusCode.PaymentRequired,
                    new { detail = "Créditos insuficientes. Por favor, adquira mais análises." });

            // Lê arquivo
            var provider = new MultipartMemoryStreamProvider();
            await Request.Content.ReadAsMultipartAsync(provider);

            byte[] fileBytes = null;
            string mimeType = "application/pdf";

            foreach (var part in provider.Contents)
            {
                if (part.Headers.ContentDisposition?.FileName != null)
                {
                    fileBytes = await part.ReadAsByteArrayAsync();
                    mimeType = part.Headers.ContentType?.MediaType ?? "application/pdf";
                    break;
                }
            }

            if (fileBytes == null || fileBytes.Length == 0)
                return BadRequest("Nenhum arquivo recebido");

            try
            {
                // Passo 1: Extração com Gemini
                var extractionResult = await AiService.CallGeminiExtractionAsync(
                    ExtractionSystem,
                    "Extraia todos os valores deste hemograma. Retorne apenas JSON.",
                    fileBytes, mimeType);

                JObject extractedData;
                try
                {
                    extractedData = JObject.Parse(AiService.CleanJsonResponse(extractionResult.Text));
                }
                catch
                {
                    extractedData = new JObject { ["raw_text"] = extractionResult.Text, ["valores"] = new JObject() };
                }

                // Passo 2: Análise com Claude → OpenAI (fallback)
                var analysisResult = await AiService.CallWithFallbackAsync(
                    AnalysisSystem,
                    $"Analise este hemograma: {extractedData.ToString(Formatting.None)}");

                JObject analysisData;
                try
                {
                    analysisData = JObject.Parse(AiService.CleanJsonResponse(analysisResult.Text));
                }
                catch
                {
                    analysisData = new JObject
                    {
                        ["summary"] = "Seus exames foram processados. Consulte os valores abaixo.",
                        ["flags"] = new JObject(),
                        ["suggested_exa_specialists"] = new JArray()
                    };
                }

                // Desconta crédito
                await DatabaseService.ExecuteAsync(
                    "UPDATE exa_tenants SET exam_credits = exam_credits - 1 WHERE id = @id",
                    new Dictionary<string, object> { ["@id"] = tenantId });

                // Tracking de uso
                var monthYear = DateTime.UtcNow.ToString("yyyy-MM");
                await DatabaseService.ExecuteAsync(
                    @"INSERT INTO exa_usage_tracking (id, tenant_id, month_year, exam_count)
                      VALUES (@id,@tid,@my,1)
                      ON DUPLICATE KEY UPDATE exam_count = exam_count + 1",
                    new Dictionary<string, object>
                    {
                        ["@id"] = Guid.NewGuid().ToString(), ["@tid"] = tenantId, ["@my"] = monthYear
                    });

                // Salva exame
                var examId = Guid.NewGuid().ToString();
                var analysisWithProviders = new JObject(analysisData)
                {
                    ["_providers"] = new JObject
                    {
                        ["extraction"] = extractionResult.Provider,
                        ["analysis"] = analysisResult.Provider
                    }
                };

                await DatabaseService.ExecuteAsync(
                    @"INSERT INTO exa_exams (id, user_id, tenant_id, extracted_data, ai_analysis, flags, summary)
                      VALUES (@id,@uid,@tid,@ed,@aa,@fl,@sm)",
                    new Dictionary<string, object>
                    {
                        ["@id"] = examId, ["@uid"] = userId, ["@tid"] = tenantId,
                        ["@ed"] = extractedData.ToString(Formatting.None),
                        ["@aa"] = analysisWithProviders.ToString(Formatting.None),
                        ["@fl"] = (analysisData["flags"] ?? new JObject()).ToString(Formatting.None),
                        ["@sm"] = analysisData["summary"]?.ToString() ?? ""
                    });

                // Mensagem inicial do chat
                await DatabaseService.ExecuteAsync(
                    "INSERT INTO exa_chat_messages (id, exam_id, user_id, role, content) VALUES (@id,@eid,@uid,'assistant',@ct)",
                    new Dictionary<string, object>
                    {
                        ["@id"] = Guid.NewGuid().ToString(), ["@eid"] = examId, ["@uid"] = userId,
                        ["@ct"] = "Analisei seu exame. Ficou alguma dúvida sobre algum valor específico? Pode me perguntar à vontade."
                    });

                var creditsRemaining = Convert.ToInt32(tenant["exam_credits"]) - 1;

                return Ok(new
                {
                    examId,
                    extractedData = extractedData,
                    analysis = analysisData,
                    creditsRemaining
                });
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception($"Erro ao processar exame: {ex.Message}"));
            }
        }

        // GET api/exams
        [HttpGet, Route("")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> GetExams(Dictionary<string, string> currentUser = null)
        {
            var userId = currentUser["user_id"];
            var exams = await DatabaseService.QueryAsync(
                "SELECT id, summary, created_at FROM exa_exams WHERE user_id = @uid ORDER BY created_at DESC LIMIT 50",
                new Dictionary<string, object> { ["@uid"] = userId });

            var result = new List<object>();
            foreach (var e in exams)
            {
                var summary = e["summary"]?.ToString() ?? "";
                result.Add(new
                {
                    id = e["id"],
                    summary = summary.Length > 150 ? summary.Substring(0, 150) + "..." : summary,
                    createdAt = e["created_at"] is DateTime dt ? dt.ToString("o") : e["created_at"]?.ToString()
                });
            }
            return Ok(result);
        }

        // GET api/exams/{id}
        [HttpGet, Route("{examId}")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> GetExam(string examId, Dictionary<string, string> currentUser = null)
        {
            var userId = currentUser["user_id"];
            var exam = await DatabaseService.QueryOneAsync(
                "SELECT * FROM exa_exams WHERE id = @id AND user_id = @uid",
                new Dictionary<string, object> { ["@id"] = examId, ["@uid"] = userId });

            if (exam == null) return NotFound();

            var messages = await DatabaseService.QueryAsync(
                "SELECT id, role, content, created_at FROM exa_chat_messages WHERE exam_id = @eid ORDER BY created_at ASC LIMIT 100",
                new Dictionary<string, object> { ["@eid"] = examId });

            var analysis = exam["ai_analysis"] != null ? JObject.Parse(exam["ai_analysis"].ToString()) : new JObject();
            var suggested = analysis["suggested_exa_specialists"] as JArray ?? new JArray();

            List<Dictionary<string, object>> specialists = new List<Dictionary<string, object>>();
            if (suggested.Count > 0)
            {
                var specialtyList = string.Join(",", suggested.Select((_, i) => $"@s{i}"));
                var specialtyParams = new Dictionary<string, object>();
                for (int i = 0; i < suggested.Count; i++)
                    specialtyParams[$"@s{i}"] = suggested[i].ToString();

                specialists = await DatabaseService.QueryAsync(
                    $"SELECT id, name, specialty, type, city, state, phone, website, email, description FROM exa_specialists WHERE specialty IN ({specialtyList}) AND active = TRUE LIMIT 10",
                    specialtyParams);
            }

            return Ok(new
            {
                id = exam["id"],
                extractedData = exam["extracted_data"] != null ? JObject.Parse(exam["extracted_data"].ToString()) : new JObject(),
                analysis = analysis,
                flags = exam["flags"] != null ? JObject.Parse(exam["flags"].ToString()) : new JObject(),
                summary = exam["summary"]?.ToString(),
                createdAt = exam["created_at"] is DateTime dt ? dt.ToString("o") : exam["created_at"]?.ToString(),
                messages = messages.Select(m => new
                {
                    id = m["id"],
                    role = m["role"],
                    content = m["content"],
                    createdAt = m["created_at"] is DateTime mdt ? mdt.ToString("o") : m["created_at"]?.ToString()
                }),
                specialists
            });
        }

        // POST api/exams/{id}/chat
        [HttpPost, Route("{examId}/chat")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> Chat(string examId, [FromBody] ChatMessageRequest message,
            Dictionary<string, string> currentUser = null)
        {
            var userId = currentUser["user_id"];
            var exam = await DatabaseService.QueryOneAsync(
                "SELECT * FROM exa_exams WHERE id = @id AND user_id = @uid",
                new Dictionary<string, object> { ["@id"] = examId, ["@uid"] = userId });

            if (exam == null) return NotFound();

            var history = await DatabaseService.QueryAsync(
                "SELECT role, content FROM exa_chat_messages WHERE exam_id = @eid ORDER BY created_at ASC LIMIT 50",
                new Dictionary<string, object> { ["@eid"] = examId });

            var userMsgId = Guid.NewGuid().ToString();
            await DatabaseService.ExecuteAsync(
                "INSERT INTO exa_chat_messages (id, exam_id, user_id, role, content) VALUES (@id,@eid,@uid,'user',@ct)",
                new Dictionary<string, object>
                {
                    ["@id"] = userMsgId, ["@eid"] = examId, ["@uid"] = userId, ["@ct"] = message.Content
                });

            var extractedData = exam["extracted_data"] != null ? exam["extracted_data"].ToString() : "{}";
            var analysis = exam["ai_analysis"] != null ? exam["ai_analysis"].ToString() : "{}";

            var systemPrompt = $@"Você é um assistente de saúde empático e acolhedor. O usuário acabou de receber resultados de um hemograma.
Regras:
- Nunca recomende medicamentos específicos
- Nunca faça diagnósticos definitivos
- Ao notar algo importante, sugira consultar um médico de forma calma
- Use linguagem simples
- Seja breve e direto

Contexto do exame:
Valores: {extractedData}
Análise: {analysis}";

            var context = string.Join("\n", history.Select(h =>
                $"{(h["role"].ToString() == "user" ? "Usuário" : "Assistente")}: {h["content"]}"));

            try
            {
                var aiResult = await AiService.CallWithFallbackAsync(
                    systemPrompt,
                    $"Histórico:\n{context}\n\nNova mensagem: {message.Content}");

                var aiMsgId = Guid.NewGuid().ToString();
                await DatabaseService.ExecuteAsync(
                    "INSERT INTO exa_chat_messages (id, exam_id, user_id, role, content) VALUES (@id,@eid,@uid,'assistant',@ct)",
                    new Dictionary<string, object>
                    {
                        ["@id"] = aiMsgId, ["@eid"] = examId, ["@uid"] = userId, ["@ct"] = aiResult.Text
                    });

                return Ok(new
                {
                    userMessage = new { id = userMsgId, content = message.Content },
                    aiResponse = new { id = aiMsgId, content = aiResult.Text }
                });
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Erro ao processar mensagem"));
            }
        }
    }
}
