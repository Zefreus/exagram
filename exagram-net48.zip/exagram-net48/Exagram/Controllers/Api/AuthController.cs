using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using Exagram.Filters;
using Exagram.Models;
using Exagram.Services;

namespace Exagram.Controllers.Api
{
    [RoutePrefix("api/auth")]
    public class AuthController : ApiController
    {
        // POST api/auth/register
        [HttpPost, Route("register")]
        public async Task<IHttpActionResult> Register([FromBody] UserRegisterRequest data)
        {
            if (data == null || !ModelState.IsValid)
                return BadRequest("Dados inválidos");

            var existing = await DatabaseService.QueryOneAsync(
                "SELECT id FROM exa_users WHERE email = @email",
                new Dictionary<string, object> { ["@email"] = data.Email });

            if (existing != null)
                return Content(System.Net.HttpStatusCode.BadRequest, new { detail = "Email já cadastrado" });

            var tenantId = Guid.NewGuid().ToString();
            var slug = data.Email.Split('@')[0] + "_" + tenantId.Substring(0, 8);

            await DatabaseService.ExecuteAsync(
                "INSERT INTO exa_tenants (id, name, slug, plan, exam_credits, active, created_at) VALUES (@id,@name,@slug,'free',1,TRUE,NOW())",
                new Dictionary<string, object> { ["@id"] = tenantId, ["@name"] = data.Name, ["@slug"] = slug });

            var userId = Guid.NewGuid().ToString();
            var hash = AuthService.HashPassword(data.Password);

            await DatabaseService.ExecuteAsync(
                "INSERT INTO exa_users (id, tenant_id, email, password_hash, name, created_at) VALUES (@id,@tid,@email,@hash,@name,NOW())",
                new Dictionary<string, object>
                {
                    ["@id"] = userId, ["@tid"] = tenantId,
                    ["@email"] = data.Email, ["@hash"] = hash, ["@name"] = data.Name
                });

            var token = AuthService.CreateToken(userId, "user", tenantId, data.Email);
            return Ok(new AuthResponse
            {
                Token = token,
                User = new UserResponse
                {
                    Id = userId, Email = data.Email, TenantId = tenantId,
                    Name = data.Name, ExamCredits = 1, Plan = "free", ConsentGranted = false
                }
            });
        }

        // POST api/auth/login
        [HttpPost, Route("login")]
        public async Task<IHttpActionResult> Login([FromBody] UserLoginRequest data)
        {
            if (data == null) return BadRequest("Dados inválidos");

            var user = await DatabaseService.QueryOneAsync(
                @"SELECT u.*, t.name as tenant_name, t.exam_credits, t.plan
                  FROM exa_users u
                  JOIN exa_tenants t ON u.tenant_id = t.id
                  WHERE u.email = @email AND t.active = TRUE",
                new Dictionary<string, object> { ["@email"] = data.Email });

            if (user == null)
                return Content(System.Net.HttpStatusCode.Unauthorized, new { detail = "Credenciais inválidas" });

            if (!AuthService.VerifyPassword(data.Password, user["password_hash"]?.ToString()))
                return Content(System.Net.HttpStatusCode.Unauthorized, new { detail = "Credenciais inválidas" });

            var token = AuthService.CreateToken(user["id"].ToString(), "user", user["tenant_id"].ToString(), data.Email);
            return Ok(new AuthResponse
            {
                Token = token,
                User = new UserResponse
                {
                    Id = user["id"].ToString(),
                    Email = user["email"].ToString(),
                    TenantId = user["tenant_id"].ToString(),
                    Name = user["tenant_name"]?.ToString(),
                    ExamCredits = Convert.ToInt32(user["exam_credits"]),
                    Plan = user["plan"]?.ToString(),
                    ConsentGranted = Convert.ToBoolean(user["consent_granted"])
                }
            });
        }

        // POST api/admin/login  — Admin
        [HttpPost]
        [Route("~/api/admin/login")]
        public async Task<IHttpActionResult> AdminLogin([FromBody] AdminLoginRequest data)
        {
            if (data == null) return BadRequest("Dados inválidos");

            var admin = await DatabaseService.QueryOneAsync(
                "SELECT * FROM exa_admins WHERE email = @email",
                new Dictionary<string, object> { ["@email"] = data.Email });

            if (admin == null)
                return Content(System.Net.HttpStatusCode.Unauthorized, new { detail = "Credenciais inválidas" });

            if (!AuthService.VerifyPassword(data.Password, admin["password_hash"]?.ToString()))
                return Content(System.Net.HttpStatusCode.Unauthorized, new { detail = "Credenciais inválidas" });

            var token = AuthService.CreateToken(admin["id"].ToString(), "admin", null, data.Email);
            return Ok(new AdminAuthResponse
            {
                Token = token,
                Admin = new AdminInfo { Id = admin["id"].ToString(), Email = data.Email }
            });
        }

        // GET api/auth/me
        [HttpGet, Route("me")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> Me(Dictionary<string, string> currentUser = null)
        {
            var userId = currentUser?["user_id"];
            var user = await DatabaseService.QueryOneAsync(
                @"SELECT u.*, t.name as tenant_name, t.exam_credits, t.plan
                  FROM exa_users u
                  JOIN exa_tenants t ON u.tenant_id = t.id
                  WHERE u.id = @id",
                new Dictionary<string, object> { ["@id"] = userId });

            if (user == null) return NotFound();

            return Ok(new UserResponse
            {
                Id = user["id"].ToString(),
                Email = user["email"].ToString(),
                TenantId = user["tenant_id"].ToString(),
                Name = user["tenant_name"]?.ToString(),
                ExamCredits = Convert.ToInt32(user["exam_credits"]),
                Plan = user["plan"]?.ToString(),
                ConsentGranted = Convert.ToBoolean(user["consent_granted"])
            });
        }
    }
}
