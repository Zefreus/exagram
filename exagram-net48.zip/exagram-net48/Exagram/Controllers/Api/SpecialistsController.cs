using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using Exagram.Models;
using Exagram.Services;

namespace Exagram.Controllers.Api
{
    [RoutePrefix("api/specialists")]
    public class SpecialistsController : ApiController
    {
        // GET api/specialists
        [HttpGet, Route("")]
        public async Task<IHttpActionResult> GetAll([FromUri] string specialty = null,
            [FromUri] string city = null, [FromUri] string state = null)
        {
            var sql = "SELECT * FROM exa_specialists WHERE active = TRUE";
            var pars = new Dictionary<string, object>();

            if (!string.IsNullOrEmpty(specialty)) { sql += " AND specialty LIKE @sp"; pars["@sp"] = $"%{specialty}%"; }
            if (!string.IsNullOrEmpty(city)) { sql += " AND city LIKE @city"; pars["@city"] = $"%{city}%"; }
            if (!string.IsNullOrEmpty(state)) { sql += " AND state = @state"; pars["@state"] = state; }
            sql += " ORDER BY name ASC LIMIT 50";

            var rows = await DatabaseService.QueryAsync(sql, pars.Count > 0 ? pars : null);
            return Ok(rows.Select(MapSpecialist));
        }

        // GET api/specialists/{id}
        [HttpGet, Route("{id}")]
        public async Task<IHttpActionResult> Get(string id)
        {
            var row = await DatabaseService.QueryOneAsync(
                "SELECT * FROM exa_specialists WHERE id = @id AND active = TRUE",
                new Dictionary<string, object> { ["@id"] = id });

            if (row == null) return NotFound();
            return Ok(MapSpecialist(row));
        }

        private static object MapSpecialist(Dictionary<string, object> r) => new
        {
            id = r["id"],
            name = r["name"],
            specialty = r["specialty"],
            type = r["type"],
            city = r["city"],
            state = r["state"],
            phone = r["phone"],
            website = r["website"],
            email = r["email"],
            description = r["description"],
            active = Convert.ToBoolean(r["active"])
        };
    }
}
