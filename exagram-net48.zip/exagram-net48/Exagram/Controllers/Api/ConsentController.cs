using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using Exagram.Filters;
using Exagram.Models;
using Exagram.Services;

namespace Exagram.Controllers.Api
{
    [RoutePrefix("api/consent")]
    public class ConsentController : ApiController
    {
        // POST api/consent/grant
        [HttpPost, Route("grant")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> Grant([FromBody] ConsentGrantRequest data,
            Dictionary<string, string> currentUser = null)
        {
            var userId = currentUser["user_id"];
            var consentVersion = System.Configuration.ConfigurationManager.AppSettings["ConsentVersion"] ?? "1.0";

            await DatabaseService.ExecuteAsync(
                @"INSERT INTO exa_consents (id, user_id, consent_version, ip_address, user_agent, action, type)
                  VALUES (@id,@uid,@cv,@ip,@ua,'granted',@type)",
                new Dictionary<string, object>
                {
                    ["@id"] = Guid.NewGuid().ToString(),
                    ["@uid"] = userId,
                    ["@cv"] = consentVersion,
                    ["@ip"] = data?.IpAddress ?? "",
                    ["@ua"] = data?.UserAgent ?? "",
                    ["@type"] = data?.Type ?? "terms"
                });

            await DatabaseService.ExecuteAsync(
                "UPDATE exa_users SET consent_granted = TRUE WHERE id = @id",
                new Dictionary<string, object> { ["@id"] = userId });

            return Ok(new { success = true });
        }

        // GET api/consent/status
        [HttpGet, Route("status")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> Status(Dictionary<string, string> currentUser = null)
        {
            var userId = currentUser["user_id"];
            var user = await DatabaseService.QueryOneAsync(
                "SELECT consent_granted FROM exa_users WHERE id = @id",
                new Dictionary<string, object> { ["@id"] = userId });

            return Ok(new
            {
                consentGranted = user != null && Convert.ToBoolean(user["consent_granted"]),
                consentVersion = System.Configuration.ConfigurationManager.AppSettings["ConsentVersion"] ?? "1.0"
            });
        }
    }
}
