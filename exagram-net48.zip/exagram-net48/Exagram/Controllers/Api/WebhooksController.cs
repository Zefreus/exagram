using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using Exagram.Services;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Exagram.Controllers.Api
{
    [RoutePrefix("api/webhooks")]
    public class WebhooksController : ApiController
    {
        // POST api/webhooks/mercadopago
        [HttpPost, Route("mercadopago")]
        public async Task<IHttpActionResult> MercadoPago()
        {
            try
            {
                var queryParams = Request.GetQueryNameValuePairs();
                string topic = null, resourceId = null;
                foreach (var kv in queryParams)
                {
                    if (kv.Key == "topic" || kv.Key == "type") topic = kv.Value;
                    if (kv.Key == "id" || kv.Key == "data.id") resourceId = kv.Value;
                }

                JObject body = new JObject();
                try
                {
                    var bodyStr = await Request.Content.ReadAsStringAsync();
                    if (!string.IsNullOrEmpty(bodyStr))
                        body = JObject.Parse(bodyStr);
                }
                catch { }

                // Determina payment ID
                string paymentId = null;
                if (body["type"]?.ToString() == "payment" && body["data"]?["id"] != null)
                    paymentId = body["data"]["id"].ToString();
                else if (topic == "payment" && resourceId != null)
                    paymentId = resourceId;
                else if (body["action"]?.ToString()?.StartsWith("payment") == true)
                    paymentId = body["data"]?["id"]?.ToString();

                if (!string.IsNullOrEmpty(paymentId))
                {
                    var payment = await MercadoPagoService.GetPaymentAsync(paymentId);
                    if (payment?["status"]?.ToString() == "approved")
                    {
                        var externalRef = payment["external_reference"]?.ToString();
                        var preferenceId = payment["preference_id"]?.ToString();

                        if (!string.IsNullOrEmpty(externalRef))
                        {
                            var refData = JObject.Parse(externalRef);
                            var tenantId = refData["tenant_id"]?.ToString();
                            var credits = refData["credits"]?.ToObject<int>() ?? 0;
                            var couponCode = refData["coupon_code"]?.ToString();

                            if (!string.IsNullOrEmpty(tenantId) && credits > 0)
                            {
                                var transaction = await DatabaseService.QueryOneAsync(
                                    "SELECT id, payment_status, credits_purchased FROM exa_payment_transactions WHERE session_id = @sid",
                                    new Dictionary<string, object> { ["@sid"] = preferenceId });

                                if (transaction == null)
                                    transaction = await DatabaseService.QueryOneAsync(
                                        "SELECT id, payment_status, credits_purchased FROM exa_payment_transactions WHERE tenant_id = @tid AND payment_status = 'pending' ORDER BY created_at DESC LIMIT 1",
                                        new Dictionary<string, object> { ["@tid"] = tenantId });

                                if (transaction != null && transaction["payment_status"]?.ToString() != "completed")
                                {
                                    await DatabaseService.ExecuteAsync(
                                        "UPDATE exa_tenants SET exam_credits = exam_credits + @cr WHERE id = @id",
                                        new Dictionary<string, object> { ["@cr"] = credits, ["@id"] = tenantId });

                                    await DatabaseService.ExecuteAsync(
                                        "UPDATE exa_payment_transactions SET payment_status = 'completed', mp_payment_id = @pid WHERE id = @id",
                                        new Dictionary<string, object> { ["@pid"] = paymentId, ["@id"] = transaction["id"] });

                                    if (!string.IsNullOrEmpty(couponCode))
                                        await DatabaseService.ExecuteAsync(
                                            "UPDATE exa_coupons SET times_redeemed = times_redeemed + 1 WHERE code = @code",
                                            new Dictionary<string, object> { ["@code"] = couponCode });

                                    await DatabaseService.ExecuteAsync(
                                        "INSERT INTO exa_audit_log (id, event_type, affected_count, tenant_id) VALUES (@id,'payment_completed',@cr,@tid)",
                                        new Dictionary<string, object>
                                        {
                                            ["@id"] = Guid.NewGuid().ToString(), ["@cr"] = credits, ["@tid"] = tenantId
                                        });
                                }
                            }
                        }
                    }
                }

                return Ok(new { received = true });
            }
            catch (Exception ex)
            {
                return Ok(new { received = true, error = ex.Message });
            }
        }
    }
}
