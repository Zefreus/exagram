using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using Exagram.Filters;
using Exagram.Services;
using Newtonsoft.Json.Linq;

namespace Exagram.Controllers.Api
{
    [RoutePrefix("api/user")]
    public class UserController : ApiController
    {
        // GET api/user/data
        [HttpGet, Route("data")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> ExportData(Dictionary<string, string> currentUser = null)
        {
            var userId = currentUser["user_id"];
            var tenantId = currentUser["tenant_id"];

            var user = await DatabaseService.QueryOneAsync(
                "SELECT id, email, created_at FROM exa_users WHERE id = @id",
                new Dictionary<string, object> { ["@id"] = userId });

            var tenant = await DatabaseService.QueryOneAsync(
                "SELECT id, name, plan, exam_credits FROM exa_tenants WHERE id = @id",
                new Dictionary<string, object> { ["@id"] = tenantId });

            var exams = await DatabaseService.QueryAsync(
                "SELECT id, extracted_data, ai_analysis, summary, created_at FROM exa_exams WHERE user_id = @uid LIMIT 1000",
                new Dictionary<string, object> { ["@uid"] = userId });

            var consents = await DatabaseService.QueryAsync(
                "SELECT type, action, timestamp, consent_version FROM exa_consents WHERE user_id = @uid LIMIT 100",
                new Dictionary<string, object> { ["@uid"] = userId });

            return Ok(new
            {
                user = new
                {
                    id = user?["id"],
                    email = user?["email"],
                    createdAt = user?["created_at"] is DateTime dt ? dt.ToString("o") : user?["created_at"]?.ToString()
                },
                tenant = new
                {
                    id = tenant?["id"],
                    name = tenant?["name"],
                    plan = tenant?["plan"],
                    credits = Convert.ToInt32(tenant?["exam_credits"])
                },
                exams = exams.Select(e => new
                {
                    id = e["id"],
                    summary = e["summary"],
                    createdAt = e["created_at"] is DateTime edt ? edt.ToString("o") : e["created_at"]?.ToString()
                }),
                consents = consents.Select(c => new
                {
                    type = c["type"],
                    action = c["action"],
                    version = c["consent_version"],
                    timestamp = c["timestamp"] is DateTime cdt ? cdt.ToString("o") : c["timestamp"]?.ToString()
                }),
                exportedAt = DateTime.UtcNow.ToString("o")
            });
        }

        // DELETE api/user/account
        [HttpDelete, Route("account")]
        [JwtUserAuth]
        public async Task<IHttpActionResult> DeleteAccount(Dictionary<string, string> currentUser = null)
        {
            var userId = currentUser["user_id"];
            var tenantId = currentUser["tenant_id"];

            var examCount = await DatabaseService.QueryOneAsync(
                "SELECT COUNT(*) as count FROM exa_exams WHERE user_id = @uid",
                new Dictionary<string, object> { ["@uid"] = userId });

            await DatabaseService.ExecuteAsync(
                "INSERT INTO exa_audit_log (id, event_type, affected_count, tenant_id) VALUES (@id,'user_deletion',@ct,@tid)",
                new Dictionary<string, object>
                {
                    ["@id"] = Guid.NewGuid().ToString(),
                    ["@ct"] = Convert.ToInt32(examCount?["count"] ?? 0),
                    ["@tid"] = tenantId
                });

            await DatabaseService.ExecuteAsync("DELETE FROM exa_chat_messages WHERE user_id = @id", new Dictionary<string, object> { ["@id"] = userId });
            await DatabaseService.ExecuteAsync("DELETE FROM exa_exams WHERE user_id = @id", new Dictionary<string, object> { ["@id"] = userId });
            await DatabaseService.ExecuteAsync("DELETE FROM exa_consents WHERE user_id = @id", new Dictionary<string, object> { ["@id"] = userId });
            await DatabaseService.ExecuteAsync("DELETE FROM exa_users WHERE id = @id", new Dictionary<string, object> { ["@id"] = userId });
            await DatabaseService.ExecuteAsync("DELETE FROM exa_usage_tracking WHERE tenant_id = @id", new Dictionary<string, object> { ["@id"] = tenantId });
            await DatabaseService.ExecuteAsync("DELETE FROM exa_payment_transactions WHERE tenant_id = @id", new Dictionary<string, object> { ["@id"] = tenantId });
            await DatabaseService.ExecuteAsync("DELETE FROM exa_tenants WHERE id = @id", new Dictionary<string, object> { ["@id"] = tenantId });

            return Ok(new { success = true, message = "Conta e todos os dados foram excluídos permanentemente" });
        }
    }
}
