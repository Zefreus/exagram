using System.Web.Mvc;

namespace Exagram.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index() => View("~/Views/Home/Index.cshtml");
        public ActionResult Login() => View("~/Views/Auth/Login.cshtml");
        public ActionResult Register() => View("~/Views/Auth/Register.cshtml");
        public ActionResult Dashboard() => View("~/Views/Dashboard/Index.cshtml");
        public ActionResult ExamResult(string id) { ViewBag.ExamId = id; return View("~/Views/Exam/Result.cshtml"); }
        public ActionResult Admin() => View("~/Views/Admin/Index.cshtml");
        public ActionResult AdminLogin() => View("~/Views/Admin/Login.cshtml");
    }
}
